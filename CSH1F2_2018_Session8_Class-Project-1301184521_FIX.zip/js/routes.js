angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('mainMenu', {
    url: '/main',
    templateUrl: 'templates/mainMenu.html',
    controller: 'mainMenuCtrl'
  })

  .state('introduction', {
    url: '/introduction',
    templateUrl: 'templates/introduction.html',
    controller: 'introductionCtrl'
  })

  .state('curriculumVitae', {
    url: '/curriculumVitae',
    templateUrl: 'templates/curriculumVitae.html',
    controller: 'curriculumVitaeCtrl'
  })

  .state('contact', {
    url: '/contact',
    templateUrl: 'templates/contact.html',
    controller: 'contactCtrl'
  })

$urlRouterProvider.otherwise('/main')


});